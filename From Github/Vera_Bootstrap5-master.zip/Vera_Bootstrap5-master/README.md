# Vera Software Solutions - Bootstrap 5 Services Page.

## IMPORTANT: All credits of Original Design Concepts to Brad Traversy (traversymedia.com).

## DISCLAIMER: The original design concept(s) of this project(s) is NOT mine; nevertheless, I have changed/modified the Source Code, incorporating my own custom ideas, design(s), and/or Code Snippets to better suit my own vision(s) of the project(s) in question.
